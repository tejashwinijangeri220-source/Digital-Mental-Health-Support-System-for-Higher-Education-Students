"""
Smart Campus Resource Booking & Utilization System
Backend - Flask + MySQL
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
import mysql.connector
import bcrypt
import json
from datetime import datetime, date, timedelta
from functools import wraps
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'campus-secret-key-2024')
CORS(app, supports_credentials=True)

# ─────────────────────────────────────────
# DATABASE CONFIG  (update as needed)
# ─────────────────────────────────────────
DB_CONFIG = {
    'host':     os.environ.get('DB_HOST',     'localhost'),
    'user':     os.environ.get('DB_USER',     'root'),
    'password': os.environ.get('DB_PASSWORD', ''),
    'database': os.environ.get('DB_NAME',     'smart_campus'),
    'autocommit': True,
}


def get_db():
    """Return a fresh MySQL connection."""
    return mysql.connector.connect(**DB_CONFIG)


def db_query(sql, params=None, fetchone=False, fetchall=False):
    conn = get_db()
    cur  = conn.cursor(dictionary=True)
    cur.execute(sql, params or ())
    if fetchone:  result = cur.fetchone()
    elif fetchall: result = cur.fetchall()
    else:          result = cur.lastrowid
    cur.close(); conn.close()
    return result


# ─────────────────────────────────────────
# AUTH HELPERS
# ─────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return login_required(decorated)


# ─────────────────────────────────────────
# AUTH ROUTES
# ─────────────────────────────────────────
@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    required = ['name', 'email', 'password', 'role']
    if not all(k in data for k in required):
        return jsonify({'error': 'Missing fields'}), 400

    hashed = bcrypt.hashpw(data['password'].encode(), bcrypt.gensalt()).decode()
    try:
        uid = db_query(
            "INSERT INTO users (name, email, password, role, department) VALUES (%s,%s,%s,%s,%s)",
            (data['name'], data['email'], hashed, data.get('role','student'), data.get('department',''))
        )
        return jsonify({'message': 'Registration successful', 'user_id': uid}), 201
    except mysql.connector.IntegrityError:
        return jsonify({'error': 'Email already registered'}), 409


@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    user = db_query("SELECT * FROM users WHERE email=%s AND is_active=1",
                    (data.get('email',''),), fetchone=True)
    if not user or not bcrypt.checkpw(data['password'].encode(), user['password'].encode()):
        return jsonify({'error': 'Invalid credentials'}), 401

    session['user_id'] = user['id']
    session['role']    = user['role']
    return jsonify({
        'message': 'Login successful',
        'user': {k: user[k] for k in ('id','name','email','role','department')}
    })


@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out'})


@app.route('/api/me', methods=['GET'])
@login_required
def me():
    user = db_query("SELECT id,name,email,role,department,created_at FROM users WHERE id=%s",
                    (session['user_id'],), fetchone=True)
    return jsonify(user)


# ─────────────────────────────────────────
# RESOURCES
# ─────────────────────────────────────────
@app.route('/api/resources', methods=['GET'])
def get_resources():
    cat   = request.args.get('category')
    query = """
        SELECT r.*, c.name AS category_name, c.icon AS category_icon, c.color AS category_color
        FROM resources r LEFT JOIN categories c ON r.category_id = c.id
        WHERE r.status = 'available'
    """
    params = []
    if cat:
        query += " AND r.category_id = %s"
        params.append(cat)
    resources = db_query(query, params, fetchall=True)
    # Parse amenities JSON
    for r in resources:
        if isinstance(r.get('amenities'), str):
            r['amenities'] = json.loads(r['amenities'])
    return jsonify(resources)


@app.route('/api/resources/<int:rid>', methods=['GET'])
def get_resource(rid):
    r = db_query(
        """SELECT r.*, c.name AS category_name, c.color AS category_color
           FROM resources r LEFT JOIN categories c ON r.category_id = c.id
           WHERE r.id=%s""",
        (rid,), fetchone=True
    )
    if not r:
        return jsonify({'error': 'Not found'}), 404
    if isinstance(r.get('amenities'), str):
        r['amenities'] = json.loads(r['amenities'])
    return jsonify(r)


@app.route('/api/resources', methods=['POST'])
@login_required
def create_resource():
    if session.get('role') not in ('admin', 'faculty'):
        return jsonify({'error': 'Unauthorized'}), 403
    d = request.json
    rid = db_query(
        """INSERT INTO resources (name, category_id, location, capacity, description, amenities)
           VALUES (%s,%s,%s,%s,%s,%s)""",
        (d['name'], d['category_id'], d.get('location',''), d.get('capacity',1),
         d.get('description',''), json.dumps(d.get('amenities',[])))
    )
    return jsonify({'message': 'Resource created', 'id': rid}), 201


# ─────────────────────────────────────────
# CATEGORIES
# ─────────────────────────────────────────
@app.route('/api/categories', methods=['GET'])
def get_categories():
    cats = db_query("SELECT * FROM categories", fetchall=True)
    # Attach resource counts
    for c in cats:
        row = db_query(
            "SELECT COUNT(*) AS cnt FROM resources WHERE category_id=%s AND status='available'",
            (c['id'],), fetchone=True
        )
        c['resource_count'] = row['cnt'] if row else 0
    return jsonify(cats)


# ─────────────────────────────────────────
# AVAILABILITY CHECK
# ─────────────────────────────────────────
@app.route('/api/resources/<int:rid>/availability', methods=['GET'])
def check_availability(rid):
    d = request.args.get('date', date.today().isoformat())
    slots = db_query(
        """SELECT start_time, end_time, status FROM bookings
           WHERE resource_id=%s AND booking_date=%s AND status IN ('pending','confirmed')""",
        (rid, d), fetchall=True
    )
    booked = [{'start': str(s['start_time']), 'end': str(s['end_time'])} for s in slots]
    return jsonify({'date': d, 'booked_slots': booked})


# ─────────────────────────────────────────
# BOOKINGS
# ─────────────────────────────────────────
@app.route('/api/bookings', methods=['POST'])
@login_required
def create_booking():
    d = request.json
    # Conflict check
    conflict = db_query(
        """SELECT id FROM bookings
           WHERE resource_id=%s AND booking_date=%s AND status IN ('pending','confirmed')
             AND NOT (end_time <= %s OR start_time >= %s)""",
        (d['resource_id'], d['booking_date'], d['start_time'], d['end_time']),
        fetchone=True
    )
    if conflict:
        return jsonify({'error': 'Time slot already booked'}), 409

    bid = db_query(
        """INSERT INTO bookings (user_id, resource_id, title, description,
                                  booking_date, start_time, end_time, attendees, notes)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (session['user_id'], d['resource_id'], d['title'], d.get('description',''),
         d['booking_date'], d['start_time'], d['end_time'],
         d.get('attendees',1), d.get('notes',''))
    )
    # Auto-confirm for now
    db_query("UPDATE bookings SET status='confirmed' WHERE id=%s", (bid,))
    # Notification
    db_query(
        "INSERT INTO notifications (user_id, message, type) VALUES (%s,%s,'success')",
        (session['user_id'], f"Your booking (ID #{bid}) has been confirmed!")
    )
    return jsonify({'message': 'Booking confirmed', 'booking_id': bid}), 201


@app.route('/api/bookings', methods=['GET'])
@login_required
def get_bookings():
    role = session.get('role')
    uid  = session['user_id']
    if role == 'admin':
        rows = db_query(
            """SELECT b.*, r.name AS resource_name, r.location,
                      c.name AS category_name, u.name AS user_name, u.email AS user_email
               FROM bookings b
               JOIN resources r ON b.resource_id = r.id
               LEFT JOIN categories c ON r.category_id = c.id
               JOIN users u ON b.user_id = u.id
               ORDER BY b.created_at DESC LIMIT 200""",
            fetchall=True
        )
    else:
        rows = db_query(
            """SELECT b.*, r.name AS resource_name, r.location,
                      c.name AS category_name
               FROM bookings b
               JOIN resources r ON b.resource_id = r.id
               LEFT JOIN categories c ON r.category_id = c.id
               WHERE b.user_id=%s ORDER BY b.created_at DESC""",
            (uid,), fetchall=True
        )
    for r in rows:
        for k in ('booking_date', 'start_time', 'end_time', 'created_at', 'updated_at'):
            if k in r and r[k] is not None:
                r[k] = str(r[k])
    return jsonify(rows)


@app.route('/api/bookings/<int:bid>', methods=['PUT'])
@login_required
def update_booking(bid):
    booking = db_query("SELECT * FROM bookings WHERE id=%s", (bid,), fetchone=True)
    if not booking:
        return jsonify({'error': 'Not found'}), 404
    if booking['user_id'] != session['user_id'] and session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    d      = request.json
    status = d.get('status', booking['status'])
    db_query("UPDATE bookings SET status=%s, notes=%s WHERE id=%s",
             (status, d.get('notes', booking['notes']), bid))
    return jsonify({'message': 'Booking updated'})


@app.route('/api/bookings/<int:bid>/cancel', methods=['POST'])
@login_required
def cancel_booking(bid):
    booking = db_query("SELECT * FROM bookings WHERE id=%s", (bid,), fetchone=True)
    if not booking:
        return jsonify({'error': 'Not found'}), 404
    if booking['user_id'] != session['user_id'] and session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    db_query("UPDATE bookings SET status='cancelled' WHERE id=%s", (bid,))
    db_query(
        "INSERT INTO notifications (user_id, message, type) VALUES (%s,%s,'warning')",
        (booking['user_id'], f"Booking #{bid} has been cancelled.")
    )
    return jsonify({'message': 'Booking cancelled'})


# ─────────────────────────────────────────
# NOTIFICATIONS
# ─────────────────────────────────────────
@app.route('/api/notifications', methods=['GET'])
@login_required
def get_notifications():
    rows = db_query(
        "SELECT * FROM notifications WHERE user_id=%s ORDER BY created_at DESC LIMIT 20",
        (session['user_id'],), fetchall=True
    )
    for r in rows:
        r['created_at'] = str(r['created_at'])
    return jsonify(rows)


@app.route('/api/notifications/read', methods=['POST'])
@login_required
def mark_read():
    db_query("UPDATE notifications SET is_read=1 WHERE user_id=%s", (session['user_id'],))
    return jsonify({'message': 'Marked read'})


# ─────────────────────────────────────────
# ANALYTICS
# ─────────────────────────────────────────
@app.route('/api/analytics/overview', methods=['GET'])
@login_required
def analytics_overview():
    today = date.today().isoformat()
    total_resources  = db_query("SELECT COUNT(*) AS c FROM resources WHERE status='available'",       fetchone=True)['c']
    total_bookings   = db_query("SELECT COUNT(*) AS c FROM bookings",                                  fetchone=True)['c']
    active_bookings  = db_query("SELECT COUNT(*) AS c FROM bookings WHERE status='confirmed' AND booking_date >= %s", (today,), fetchone=True)['c']
    total_users      = db_query("SELECT COUNT(*) AS c FROM users",                                     fetchone=True)['c']
    cancelled        = db_query("SELECT COUNT(*) AS c FROM bookings WHERE status='cancelled'",         fetchone=True)['c']

    # Bookings per category
    by_category = db_query(
        """SELECT c.name, COUNT(b.id) AS bookings
           FROM bookings b JOIN resources r ON b.resource_id=r.id
           JOIN categories c ON r.category_id=c.id
           GROUP BY c.id ORDER BY bookings DESC""",
        fetchall=True
    )
    # Bookings last 7 days
    trend = []
    for i in range(6, -1, -1):
        d = (date.today() - timedelta(days=i)).isoformat()
        cnt = db_query("SELECT COUNT(*) AS c FROM bookings WHERE booking_date=%s", (d,), fetchone=True)['c']
        trend.append({'date': d, 'count': cnt})

    # Top resources
    top = db_query(
        """SELECT r.name, COUNT(b.id) AS bookings
           FROM bookings b JOIN resources r ON b.resource_id=r.id
           GROUP BY r.id ORDER BY bookings DESC LIMIT 5""",
        fetchall=True
    )
    # Status breakdown
    status_dist = db_query(
        "SELECT status, COUNT(*) AS count FROM bookings GROUP BY status",
        fetchall=True
    )

    return jsonify({
        'total_resources':  total_resources,
        'total_bookings':   total_bookings,
        'active_bookings':  active_bookings,
        'total_users':      total_users,
        'cancelled':        cancelled,
        'by_category':      by_category,
        'trend':            trend,
        'top_resources':    top,
        'status_dist':      status_dist,
    })


# ─────────────────────────────────────────
# ADMIN – USER MANAGEMENT
# ─────────────────────────────────────────
@app.route('/api/admin/users', methods=['GET'])
@login_required
def admin_users():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Forbidden'}), 403
    users = db_query(
        "SELECT id, name, email, role, department, created_at, is_active FROM users ORDER BY created_at DESC",
        fetchall=True
    )
    for u in users:
        u['created_at'] = str(u['created_at'])
    return jsonify(users)


@app.route('/api/admin/users/<int:uid>/toggle', methods=['POST'])
@login_required
def toggle_user(uid):
    if session.get('role') != 'admin':
        return jsonify({'error': 'Forbidden'}), 403
    user = db_query("SELECT is_active FROM users WHERE id=%s", (uid,), fetchone=True)
    new_status = 0 if user['is_active'] else 1
    db_query("UPDATE users SET is_active=%s WHERE id=%s", (new_status, uid))
    return jsonify({'message': 'User status updated', 'is_active': bool(new_status)})


# ─────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────
@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'time': datetime.now().isoformat()})


if __name__ == '__main__':
    app.run(debug=True, port=5000)
