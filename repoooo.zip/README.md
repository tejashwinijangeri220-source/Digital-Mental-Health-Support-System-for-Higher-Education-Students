# 🎓 SmartCampus — Resource Booking & Utilization System

A full-stack campus resource management platform built with **Python (Flask)**, **MySQL**, and a vanilla HTML/CSS/JS frontend.

---

## 📁 Project Structure

```
smart_campus/
├── database/
│   └── schema.sql          # MySQL schema + seed data
├── backend/
│   ├── app.py              # Flask REST API
│   └── requirements.txt    # Python dependencies
└── frontend/
    └── index.html          # Single-page application
```

---

## 🗄️ Database Setup

```bash
# 1. Log in to MySQL
mysql -u root -p

# 2. Run the schema
mysql -u root -p < database/schema.sql
```

This creates the `smart_campus` database with:
- **users** — students, faculty, admins
- **resources** — classrooms, labs, conference rooms, etc.
- **categories** — resource types
- **bookings** — reservation records
- **notifications** — user alerts
- **utilization_logs** — analytics data

---

## ⚙️ Backend Setup

```bash
cd backend

# Create a virtual environment
python -m venv venv
source venv/bin/activate    # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables (optional)
export DB_HOST=localhost
export DB_USER=root
export DB_PASSWORD=your_password
export DB_NAME=smart_campus
export SECRET_KEY=your-secret-key

# Run the server
python app.py
# → Runs on http://localhost:5000
```

---

## 🌐 Frontend Setup

Simply open `frontend/index.html` in a browser.  
No build step required — it's a single HTML file.

> **Note:** When the Flask backend is running, the frontend connects to `http://localhost:5000/api`.  
> Without the backend, it falls back to built-in **mock data** so you can explore the full UI.

---

## 🔐 Demo Credentials

| Role    | Email                    | Password     |
|---------|--------------------------|--------------|
| Admin   | admin@campus.edu         | password123  |
| Faculty | faculty@campus.edu       | password123  |
| Student | student@campus.edu       | password123  |

---

## 🚀 Features

### For Students & Faculty
- 📋 Browse all campus resources with filtering by category
- 🔍 Real-time search across resources
- 📅 Book resources with conflict detection
- 👁️ View and cancel personal bookings
- 🔔 In-app notifications for booking status

### For Admins
- 📊 Analytics dashboard with charts and KPIs
- 🏛️ Manage all resources (add/edit)
- 👥 User management (activate/deactivate accounts)
- 📈 Utilization trends across 7 days
- 📋 View and manage all bookings across campus

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/register` | Register new user |
| POST | `/api/login` | Authenticate user |
| POST | `/api/logout` | Log out |
| GET | `/api/me` | Current user info |
| GET | `/api/resources` | List resources |
| POST | `/api/resources` | Add resource (admin/faculty) |
| GET | `/api/categories` | List categories |
| GET | `/api/resources/:id/availability` | Check availability |
| POST | `/api/bookings` | Create booking |
| GET | `/api/bookings` | List bookings |
| POST | `/api/bookings/:id/cancel` | Cancel booking |
| GET | `/api/analytics/overview` | Dashboard analytics |
| GET | `/api/admin/users` | List users (admin) |
| POST | `/api/admin/users/:id/toggle` | Toggle user status (admin) |
| GET | `/api/notifications` | Get notifications |
| POST | `/api/notifications/read` | Mark all read |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | HTML5, CSS3, Vanilla JS |
| Backend | Python 3.11+, Flask 3.0, Flask-CORS |
| Database | MySQL 8.0 |
| Auth | bcrypt password hashing, Flask sessions |

---

## 📦 Resources Seeded

- Seminar Hall A101 & A102 (Classrooms)
- Computer Lab B201, Physics Lab B301, Chemistry Lab B302 (Labs)
- Conference Rooms C101 & C102
- Basketball Court & Tennis Court (Sports)
- Reading Room R1 (Library)
- Main Auditorium & Mini Auditorium
