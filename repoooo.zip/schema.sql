-- ============================================================
-- Smart Campus Resource Booking & Utilization System
-- Database Schema - MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS smart_campus;
USE smart_campus;

-- ─────────────────────────────────────────
-- USERS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(120) NOT NULL,
    email       VARCHAR(180) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    role        ENUM('student','faculty','admin') DEFAULT 'student',
    department  VARCHAR(100),
    avatar_url  VARCHAR(255),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active   BOOLEAN DEFAULT TRUE
);

-- ─────────────────────────────────────────
-- RESOURCE CATEGORIES
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(80) NOT NULL,
    icon        VARCHAR(50),
    color       VARCHAR(20)
);

INSERT INTO categories (name, icon, color) VALUES
  ('Classrooms',     'classroom',   '#4F8EF7'),
  ('Labs',           'lab',         '#7C3AED'),
  ('Conference Rooms','conference', '#059669'),
  ('Sports Facilities','sports',   '#DC2626'),
  ('Library Rooms',  'library',    '#D97706'),
  ('Auditoriums',    'auditorium',  '#0891B2');

-- ─────────────────────────────────────────
-- RESOURCES
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS resources (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    category_id     INT,
    location        VARCHAR(200),
    capacity        INT DEFAULT 1,
    description     TEXT,
    amenities       JSON,
    image_url       VARCHAR(255),
    status          ENUM('available','maintenance','retired') DEFAULT 'available',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

INSERT INTO resources (name, category_id, location, capacity, description, amenities, status) VALUES
  ('Seminar Hall A101', 1, 'Block A, Floor 1', 60,  'Large seminar hall with projector and AC',            '["Projector","AC","Whiteboard","WiFi"]',         'available'),
  ('Seminar Hall A102', 1, 'Block A, Floor 1', 40,  'Medium classroom with smart board',                   '["SmartBoard","AC","WiFi"]',                     'available'),
  ('Computer Lab B201', 2, 'Block B, Floor 2', 30,  'High-end computing lab with 30 workstations',         '["Computers","AC","Projector","WiFi"]',          'available'),
  ('Physics Lab B301',  2, 'Block B, Floor 3', 20,  'Advanced physics laboratory',                         '["Lab Equipment","AC","Safety Kit"]',            'available'),
  ('Conf Room C101',    3, 'Block C, Floor 1', 12,  'Executive conference room with video conferencing',   '["VideoConf","Whiteboard","AC","WiFi","TV"]',    'available'),
  ('Conf Room C102',    3, 'Block C, Floor 1', 8,   'Small meeting room',                                  '["Whiteboard","AC","WiFi"]',                     'available'),
  ('Basketball Court',  4, 'Sports Complex',   20,  'Indoor basketball court',                             '["Changing Rooms","Lighting","Scoreboard"]',     'available'),
  ('Tennis Court 1',    4, 'Sports Complex',   4,   'Outdoor tennis court',                                '["Net","Lighting"]',                             'available'),
  ('Reading Room R1',   5, 'Library, Floor 2', 25,  'Quiet reading room with individual desks',            '["WiFi","AC","Power Outlets"]',                  'available'),
  ('Main Auditorium',   6, 'Central Block',    500, 'Main campus auditorium for large events',             '["Stage","Sound System","AC","Projector","WiFi"]','available'),
  ('Mini Auditorium',   6, 'Central Block',    150, 'Mini auditorium for departmental events',             '["Stage","Projector","AC","WiFi"]',              'available'),
  ('Chemistry Lab B302',2, 'Block B, Floor 3', 24,  'Fully equipped chemistry laboratory',                '["Fume Hood","Lab Equipment","Safety Kit","AC"]','available');

-- ─────────────────────────────────────────
-- BOOKINGS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    resource_id     INT NOT NULL,
    title           VARCHAR(200) NOT NULL,
    description     TEXT,
    booking_date    DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    attendees       INT DEFAULT 1,
    status          ENUM('pending','confirmed','cancelled','completed') DEFAULT 'pending',
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)     REFERENCES users(id),
    FOREIGN KEY (resource_id) REFERENCES resources(id)
);

-- ─────────────────────────────────────────
-- UTILIZATION LOGS (for analytics)
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS utilization_logs (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    resource_id     INT NOT NULL,
    booking_id      INT,
    log_date        DATE NOT NULL,
    hours_used      DECIMAL(4,2) DEFAULT 0,
    FOREIGN KEY (resource_id) REFERENCES resources(id),
    FOREIGN KEY (booking_id)  REFERENCES bookings(id)
);

-- ─────────────────────────────────────────
-- NOTIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    message     TEXT NOT NULL,
    type        ENUM('info','success','warning','error') DEFAULT 'info',
    is_read     BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ─────────────────────────────────────────
-- SAMPLE USERS (password: 'password123' bcrypt hashed)
-- ─────────────────────────────────────────
INSERT INTO users (name, email, password, role, department) VALUES
  ('Admin User',    'admin@campus.edu',   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewKyNAQFR.oQ0XYS', 'admin',   'Administration'),
  ('Dr. Priya Nair','faculty@campus.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewKyNAQFR.oQ0XYS', 'faculty', 'Computer Science'),
  ('Arjun Sharma',  'student@campus.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewKyNAQFR.oQ0XYS', 'student', 'Electronics');
